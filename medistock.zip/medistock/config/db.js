const { DatabaseSync } = require('node:sqlite');
const fs = require('fs');

const db = new DatabaseSync('database/medistock.db');
db.exec(fs.readFileSync('database/schema.sql', 'utf8'));
// Add doctor and hospital columns. If they already exist, the error is ignored.
try { db.exec('ALTER TABLE schedules ADD COLUMN doctor TEXT'); } catch (e) {}
try { db.exec('ALTER TABLE schedules ADD COLUMN hospital TEXT'); } catch (e) {}

module.exports = db;