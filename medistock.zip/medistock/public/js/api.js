// Makes text safe to show on the page
function esc(text) {
  return String(text).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function currentUser() {
  return JSON.parse(localStorage.getItem('user'));
}

// Talk to the server. Example: api('medicines')
async function api(path, method, body) {
  const response = await fetch('/api/' + path, {
    method: method || 'GET',
    headers: {
      'Content-Type': 'application/json',
      Authorization: 'Bearer ' + localStorage.getItem('token')
    },
    body: body ? JSON.stringify(body) : undefined
  });
  const data = await response.json();
  if (!response.ok) {
    throw new Error(data.error || 'Something went wrong');
  }
  return data;
}

function logout() {
  localStorage.clear();
  location.href = '/index.html';
}

// Send the user to the login page if their role is not allowed here
function requireRole(roles) {
  const user = currentUser();
  if (!user || !roles.includes(user.role)) {
    location.href = '/login.html';
  }
  return user;
}